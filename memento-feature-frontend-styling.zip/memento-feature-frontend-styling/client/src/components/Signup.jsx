import React, { Component } from 'react'

export class Signup extends Component {
  render() {
    return (
      <div>
        <h1>Signup</h1>
      </div>
    )
  }
}

export default Signup
